package com.example.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.receiver.AlarmReceiver
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

object AlarmScheduler {
    fun scheduleAlarm(context: Context, id: Int, hour: Int, minute: Int, daysOfWeek: String, label: String, isTaskAlarm: Boolean) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("ALARM_ID", id)
            putExtra("ALARM_HOUR", hour)
            putExtra("ALARM_MINUTE", minute)
            putExtra("ALARM_DAYS", daysOfWeek)
            putExtra("ALARM_LABEL", label)
            putExtra("IS_TASK_ALARM", isTaskAlarm)
        }
        
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        
        val requestCode = if (isTaskAlarm) id + 10000 else id
        val pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, flags)
        
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        
        // If the scheduled time is in the past, schedule for tomorrow
        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
            Log.d("AlarmScheduler", "Alarm scheduled: RequestCode=$requestCode at $hour:$minute. Title=$label.")
        } catch (e: SecurityException) {
            // Fallback if exact alarm scheduling is restricted
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
            Log.d("AlarmScheduler", "Alarm scheduled with normal permission: RequestCode=$requestCode at $hour:$minute")
        }
    }

    fun cancelAlarm(context: Context, id: Int, isTaskAlarm: Boolean) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java)
        
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        
        val requestCode = if (isTaskAlarm) id + 10000 else id
        val pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, flags)
        
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
        Log.d("AlarmScheduler", "Alarm cancelled: RequestCode=$requestCode")
    }
}

class AlarmRepository(
    private val alarmDao: AlarmDao,
    private val context: Context
) {
    val allAlarms: Flow<List<Alarm>> = alarmDao.getAllAlarms()

    suspend fun insertAlarm(alarm: Alarm): Long {
        val id = alarmDao.insertAlarm(alarm)
        val savedAlarm = alarmDao.getAlarmById(id.toInt()) ?: alarm.copy(id = id.toInt())
        if (savedAlarm.isEnabled) {
            AlarmScheduler.scheduleAlarm(
                context,
                savedAlarm.id,
                savedAlarm.hour,
                savedAlarm.minute,
                savedAlarm.daysOfWeek,
                savedAlarm.label.ifEmpty { "Jam Alarm" },
                isTaskAlarm = false
            )
        }
        return id
    }

    suspend fun updateAlarm(alarm: Alarm) {
        alarmDao.updateAlarm(alarm)
        if (alarm.isEnabled) {
            AlarmScheduler.scheduleAlarm(
                context,
                alarm.id,
                alarm.hour,
                alarm.minute,
                alarm.daysOfWeek,
                alarm.label.ifEmpty { "Jam Alarm" },
                isTaskAlarm = false
            )
        } else {
            AlarmScheduler.cancelAlarm(context, alarm.id, isTaskAlarm = false)
        }
    }

    suspend fun deleteAlarm(alarm: Alarm) {
        alarmDao.deleteAlarm(alarm)
        AlarmScheduler.cancelAlarm(context, alarm.id, isTaskAlarm = false)
    }

    suspend fun toggleAlarm(alarm: Alarm) {
        val updated = alarm.copy(isEnabled = !alarm.isEnabled)
        updateAlarm(updated)
    }
    
    suspend fun getActiveAlarms(): List<Alarm> = alarmDao.getActiveAlarms()
}

class TaskRepository(
    private val taskDao: TaskDao,
    private val context: Context
) {
    val allTasks: Flow<List<Task>> = taskDao.getAllTasks()

    suspend fun insertTask(task: Task): Long {
        val id = taskDao.insertTask(task)
        val savedTask = taskDao.getTaskById(id.toInt()) ?: task.copy(id = id.toInt())
        if (savedTask.hasAlarm && !savedTask.isCompleted) {
            AlarmScheduler.scheduleAlarm(
                context,
                savedTask.id,
                savedTask.alarmHour,
                savedTask.alarmMinute,
                "", // One-off
                "Tugas: ${savedTask.title}",
                isTaskAlarm = true
            )
        }
        return id
    }

    suspend fun updateTask(task: Task) {
        taskDao.updateTask(task)
        if (task.isCompleted) {
            // Cancel alarm if completed
            AlarmScheduler.cancelAlarm(context, task.id, isTaskAlarm = true)
        } else if (task.hasAlarm) {
            AlarmScheduler.scheduleAlarm(
                context,
                task.id,
                task.alarmHour,
                task.alarmMinute,
                "",
                "Tugas: ${task.title}",
                isTaskAlarm = true
            )
        } else {
            AlarmScheduler.cancelAlarm(context, task.id, isTaskAlarm = true)
        }
    }

    suspend fun deleteTask(task: Task) {
        taskDao.deleteTask(task)
        AlarmScheduler.cancelAlarm(context, task.id, isTaskAlarm = true)
    }
}
