package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val label: String,
    val isEnabled: Boolean = true,
    val isRecurring: Boolean = false,
    val daysOfWeek: String = "", // e.g. "Sen,Sel,Rab" or "1,2,3" etc
    val linkedTaskId: Int? = null
) : Serializable

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long? = null,
    val hasAlarm: Boolean = false,
    val alarmHour: Int = 0,
    val alarmMinute: Int = 0
) : Serializable
