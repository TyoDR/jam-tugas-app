package com.example.receiver

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra("ALARM_ID", -1)
        val label = intent.getStringExtra("ALARM_LABEL") ?: "Waktunya Tugas & Alarm!"
        val hour = intent.getIntExtra("ALARM_HOUR", -1)
        val minute = intent.getIntExtra("ALARM_MINUTE", -1)
        val daysOfWeek = intent.getStringExtra("ALARM_DAYS") ?: ""
        val isTaskAlarm = intent.getBooleanExtra("IS_TASK_ALARM", false)

        Log.d("AlarmReceiver", "Received broadcast: id=$alarmId, label=$label, hour=$hour, minute=$minute, days=$daysOfWeek, isTaskAlarm=$isTaskAlarm")

        if (alarmId == -1) return

        // If it's a regular alarm and recurring, check day of week
        if (!isTaskAlarm && daysOfWeek.isNotEmpty()) {
            val calendar = Calendar.getInstance()
            val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
            val indonesianDayString = getIndonesianDayAbbreviation(dayOfWeek)
            if (!daysOfWeek.contains(indonesianDayString)) {
                Log.d("AlarmReceiver", "Recurring alarm skipped. Today $indonesianDayString is not in scheduled days: $daysOfWeek")
                
                // Reschedule for tomorrow to keep the cycle going
                rescheduleAlarmForNextDay(context, alarmId, hour, minute, daysOfWeek, label, isTaskAlarm)
                return
            }
        }

        // Trigger Notification
        showNotification(context, alarmId, label, isTaskAlarm)

        // Reschedule recurring alarm for tomorrow, or disable if one-off regular alarm
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                if (isTaskAlarm) {
                    // One-off task alarms: we can just mark that it has fired or do nothing in DB
                } else {
                    val alarmDao = db.alarmDao
                    val alarm = alarmDao.getAlarmById(alarmId)
                    if (alarm != null) {
                        if (!alarm.isRecurring) {
                            // Turn off toggle since it's a one-off and has already fired
                            alarmDao.updateAlarm(alarm.copy(isEnabled = false))
                            Log.d("AlarmReceiver", "One-off alarm disabled in DB")
                        } else {
                            // Schedule next instance of recurring alarm for tomorrow
                            rescheduleAlarmForNextDay(context, alarmId, hour, minute, daysOfWeek, label, isTaskAlarm)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("AlarmReceiver", "Error updating alarm in DB", e)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showNotification(context: Context, id: Int, message: String, isTask: Boolean) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "JAM_ALARM_PENGINGAT_CHANNEL"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Jam Alarm & Pengingat Tugas",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Saluran untuk notifikasi Jam Alarm dan Pengingat Tugas"
                enableVibration(true)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notifyIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        
        val contentPendingIntent = PendingIntent.getActivity(context, id, notifyIntent, flags)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notificationBuilder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if (isTask) "Pengingat Tugas Harian" else "Jam Alarm Berdering")
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(contentPendingIntent)
            .setVibrate(longArrayOf(0, 500, 200, 500, 200, 500))

        notificationManager.notify(if (isTask) id + 20000 else id, notificationBuilder.build())
    }

    private fun rescheduleAlarmForNextDay(
        context: Context, id: Int, hour: Int, minute: Int, daysOfWeek: String, label: String, isTask: Boolean
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("ALARM_ID", id)
            putExtra("ALARM_HOUR", hour)
            putExtra("ALARM_MINUTE", minute)
            putExtra("ALARM_DAYS", daysOfWeek)
            putExtra("ALARM_LABEL", label)
            putExtra("IS_TASK_ALARM", isTask)
        }
        
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        
        val requestCode = if (isTask) id + 10000 else id
        val pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, flags)
        
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // Force schedule tomorrow
            add(Calendar.DAY_OF_YEAR, 1)
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
            Log.d("AlarmReceiver", "Rescheduled recurring alarm RequestCode=$requestCode at $hour:$minute for tomorrow")
        } catch (e: Exception) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
            Log.e("AlarmReceiver", "Fallback reschedule alarm", e)
        }
    }

    private fun getIndonesianDayAbbreviation(dayOfWeek: Int): String {
        return when (dayOfWeek) {
            Calendar.MONDAY -> "Sen"
            Calendar.TUESDAY -> "Sel"
            Calendar.WEDNESDAY -> "Rab"
            Calendar.THURSDAY -> "Kam"
            Calendar.FRIDAY -> "Jum"
            Calendar.SATURDAY -> "Sab"
            Calendar.SUNDAY -> "Min"
            else -> ""
        }
    }
}
