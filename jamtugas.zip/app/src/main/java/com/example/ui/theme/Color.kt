package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Clean Minimalism theme colors
val CleanPrimary = Color(0xFF6750A4)
val CleanSecondary = Color(0xFF625B71)
val CleanTertiary = Color(0xFF7D5260)
val CleanBackground = Color(0xFFFDF8FF)
val CleanSurface = Color(0xFFFFFFFF)
val CleanPrimaryContainer = Color(0xFFEADDFF)
val CleanOnPrimaryContainer = Color(0xFF21005D)
val CleanSurfaceVariant = Color(0xFFF3EDF7)
val CleanOnSurfaceVariant = Color(0xFF1D192B)
val CleanOutline = Color(0xFFCAC4D0)
val CleanSecondaryContainer = Color(0xFFE8DEF8)

// Dark Clean Minimalism theme fallback colors
val CleanPrimaryDark = Color(0xFFD0BCFF)
val CleanSecondaryDark = Color(0xFFCCC2DC)
val CleanTertiaryDark = Color(0xFFEFB8C8)
val CleanBackgroundDark = Color(0xFF141218)
val CleanSurfaceDark = Color(0xFF1D1B20)
val CleanPrimaryContainerDark = Color(0xFF4F378B)
val CleanOnPrimaryContainerDark = Color(0xFFEADDFF)
val CleanSurfaceVariantDark = Color(0xFF49454F)
val CleanOnSurfaceVariantDark = Color(0xFFCAC4D0)
val CleanOutlineDark = Color(0xFF938F99)
val CleanSecondaryContainerDark = Color(0xFF4A4458)
